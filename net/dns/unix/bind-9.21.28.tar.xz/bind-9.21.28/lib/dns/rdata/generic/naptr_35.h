/*
 * Copyright (C) Internet Systems Consortium, Inc. ("ISC")
 *
 * SPDX-License-Identifier: MPL-2.0
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, you can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * See the COPYRIGHT file distributed with this work for additional
 * information regarding copyright ownership.
 */

#pragma once

/*!
 *  \brief Per RFC2915 */

typedef struct dns_rdata_naptr {
	dns_rdatacommon_t common;
	uint16_t order;
	uint16_t preference;
	unsigned char *flags;
	uint8_t flags_len;
	unsigned char *service;
	uint8_t service_len;
	unsigned char *regexp;
	uint8_t regexp_len;
	dns_name_t replacement;
} dns_rdata_naptr_t;
