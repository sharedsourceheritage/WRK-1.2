/*
 * Copyright (C) Internet Systems Consortium, Inc. ("ISC")
 *
 * SPDX-License-Identifier: MPL-2.0
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, you can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * See the COPYRIGHT file distributed with this work for additional
 * information regarding copyright ownership.
 */

#pragma once

/*****
***** Module Info
*****/

/*! \file dns/byaddr.h
 * \brief
 * The byaddr module provides reverse lookup services for IPv4 and IPv6
 * addresses.
 *
 * MP:
 *\li	The module ensures appropriate synchronization of data structures it
 *	creates and manipulates.
 *
 * Reliability:
 *\li	No anticipated impact.
 *
 * Resources:
 *\li	TBS
 *
 * Security:
 *\li	No anticipated impact.
 *
 * Standards:
 *\li	RFCs:	1034, 1035, 2181, TBS
 *\li	Drafts:	TBS
 */

#include <dns/types.h>

isc_result_t
dns_byaddr_createptrname(const isc_netaddr_t *address, dns_name_t *name);
/*%<
 * Creates a name that would be used in a PTR query for this address.
 *
 * Requires:
 *
 * \li	'address' is a valid address.
 * \li	'name' is a valid name with a dedicated buffer.
 */

isc_result_t
dns_byaddr_parseptrname(const dns_name_t *name, isc_netaddr_t *addr);
/*%<
 * Parse a name in a PTR format and convert it into a isc_net_addr_t. Support
 * both IPv4 and IPv6 reverse format.
 *
 * Requires:
 *
 * \li	'name' is a valid name.
 * \li  'addr' is a valid object
 */
