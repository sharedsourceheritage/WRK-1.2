/*
 * Copyright (C) Internet Systems Consortium, Inc. ("ISC")
 *
 * SPDX-License-Identifier: MPL-2.0
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, you can obtain one at https://mozilla.org/MPL/2.0/.
 *
 * See the COPYRIGHT file distributed with this work for additional
 * information regarding copyright ownership.
 */

#pragma once

/*****
***** Module Info
*****/

/*! \file dns/fixedname.h
 * \brief
 * Fixed-size Names
 *
 * dns_fixedname_t is a convenience type containing a name, an offsets
 * table, and a dedicated buffer big enough for the longest possible
 * name. This is typically used for stack-allocated names.
 *
 * MP:
 *\li	The caller must ensure any required synchronization.
 *
 * Reliability:
 *\li	No anticipated impact.
 *
 * Resources:
 *\li	Per dns_fixedname_t:
 *\code
 *		sizeof(dns_name_t) + sizeof(dns_offsets_t) +
 *		sizeof(isc_buffer_t) + 255 bytes + structure padding
 *\endcode
 *
 * Security:
 *\li	No anticipated impact.
 *
 * Standards:
 *\li	None.
 */

/*****
***** Imports
*****/

#include <isc/buffer.h>
#include <isc/md.h>

#include <dns/name.h>

/*****
***** Types
*****/

struct dns_fixedname {
	dns_linkedname_t name_wl;
	isc_buffer_t	 buffer;
	unsigned char	 data[DNS_NAME_MAXWIRE];
};

typedef unsigned char dns_nsec3hash_t[ISC_SHA1_DIGESTLENGTH];

void
dns_fixedname_init(dns_fixedname_t *fixed);

void
dns_fixedname_invalidate(dns_fixedname_t *fixed);

dns_name_t *
dns_fixedname_name(dns_fixedname_t *fixed);

const dns_name_t *
dns_fixedname_name_const(const dns_fixedname_t *fixed);

dns_name_t *
dns_fixedname_initname(dns_fixedname_t *fixed);

isc_result_t
dns_fixedname_fromnsec3hash(dns_fixedname_t *fixed, const dns_nsec3hash_t *hash,
			    const dns_name_t *origin);
/*%<
 * Initialize 'fixed' with an NSEC3 owner name made from the base32hex
 * encoding of 'hash', followed by 'origin'.
 *
 * Requires:
 *\li	'fixed' is initialized.
 *\li	'hash' is non-NULL.
 *\li	'origin' is a valid absolute name.
 *
 * Returns:
 *\li	#ISC_R_NOSPACE when the resulting name does not fit in 'fixed'.
 */
dns_linkedname_t *
dns_fixedname_linkedname(dns_fixedname_t *fixed);

dns_linkedname_t *
dns_fixedname_initlinkedname(dns_fixedname_t *fixed);
