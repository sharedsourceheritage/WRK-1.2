# Frequently Asked Questions

* **Where is the documentation?** Documentation for Spec# (such as it is...) can be found at the [MSR Spec# site](http://research.microsoft.com/specsharp).