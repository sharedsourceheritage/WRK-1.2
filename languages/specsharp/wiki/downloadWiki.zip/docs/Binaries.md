**NOTE**: if you downloaded the sources, you do not need to download the binary distribution -- the source distribution contains a bootstrapping compiler.

# If you have Spec# installed from the [MSR Downloads site](http://research.microsoft.com/research/downloads/details/8826adb9-8398-40d6-a22d-951923fe2647/details.aspx), please uninstall it.
# Go to the "Downloads" tab and click on the current release to download a zip file containing all of the binaries you need to just run Spec#.
# Open a Visual Studio 2010 command prompt and navigate to the directory into which you unzipped the binaries. You will need to open that command prompt with administrator privileges (right click and select Run as Administrator).
# Execute the command {{register.cmd}}. You should see three messages telling you that the types have been registered successfully. This means that Visual Studio now knows what a Spec# project is and how to build it. If you get errors saying that RegAsm could not load a dll, try unblocking that dll (right-click the file ==> Properties ==> Unblock).
# If you want to run the program verifier (SscBoogie), you will also need to [install Z3](http://research.microsoft.com/projects/z3). We strongly recommend you to install version 2.15.
# If you have [Code Contracts](http://research.microsoft.com/contracts) installed (as every man, woman, and child on this planet ought), then you _may_ get some warning dialogs when you open Visual Studio 2010 on Spec# projects.  The fix is then to install Spec# before installing Code Contracts, so: uninstall Code Contracts, do the {{register.cmd}} step above, and then re-install Code Contracts.

Please let us know if something doesn't work!