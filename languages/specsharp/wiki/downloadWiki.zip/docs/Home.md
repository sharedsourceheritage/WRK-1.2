# Spec#
Spec# ("speck-sharp") is an object-oriented .NET programming language with design-by-contract features for method pre- and postconditions and object invariants and also a non-null type system.

* [Frequently asked questions](FAQ)
* [External Dependencies](External)
* [How to install the binaries](Binaries)
* [How to install and build the sources](Sources)
* [How to contribute](Contribute)
* [Spec# @ MSR](http://research.microsoft.com/specsharp)
* [Spec# tutorial](Tutorial)
* [Spec# workshop slides](Home_SBMF2010.pdf)
This project is sponsored by the [Research in Software Engineering Group (RiSE)](http://research.microsoft.com/rise) based in the Microsoft Research Redmond Laboratory.
