# How to contribute

* Either create a new bug or feature request that you want to work on, or find an existing one. (Add a comment to the work item noting that you're going to work on it. Until you have developer rights, you won't be able to assign work items to yourself.) 
* Download the latest sources and make the necessary changes. 
* Package up the changes as a patch and upload it (see the Source Code tab). 
* If you have not already done so, please send e-mail to mbarnett _at_ microsoft _dot_ com, who'll put you into contact with someone from the CodePlex team so that you can electronically complete an [Project Assignment Agreement](http://tfsadmin.codeplex.com/download?DownloadId=202). Note that by posting your submission to the Issue Tracker, you agree to do so under the [CodePlex TOU](http://www.codeplex.com/Legal/terms.aspx).

It will also be helpful if source code contributions from different contributors are placed in separate source files. (Partial classes make this mostly possible.)