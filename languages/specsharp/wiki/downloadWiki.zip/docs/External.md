# External Dependencies

## Spec#

### Things you must have in order to build Spec#
* **Visual Studio 2010**: Spec# is meant to be built by Visual Studio, not via makefiles. You should have at least C# and C++ installed as supported languages in Visual Studio: there are both types of projects in the Spec# solution.

## SscBoogie

### Things you must have in order to build SscBoogie
* **Spec#**: SscBoogie is written in Spec#, so you need a Spec# compiler in order to build it. You can either download the [Spec# binary distribution](http://research.microsoft.com/research/downloads/details/8826adb9-8398-40d6-a22d-951923fe2647/details.aspx) or else enlist in the [Spec# CodePlex](http://www.specsharp.codeplex.com).
* **Boogie**: SscBoogie depends on Boogie itself. If you installed the Spec# binary distribution, then you can use the Boogie binaries that come with that. Or you can get Boogie from the [Boogie CodePlex project](http://boogie.codeplex.com). From that site you can either install the binaries or download the sources and build it yourself.

### Things you need in order to run SscBoogie
* **Z3**: SscBoogie uses Boogie and its default is to generate verification conditions for [Z3](http://research.microsoft.com/en-us/um/redmond/projects/z3/). Other theorem provers can also be used, e.g., [Simplify](http://kind.ucd.ie/products/opensource/Simplify/). You will need some theorem prover that Boogie produces output for if you wish to actually find out whether a Spec# program is correct or not.