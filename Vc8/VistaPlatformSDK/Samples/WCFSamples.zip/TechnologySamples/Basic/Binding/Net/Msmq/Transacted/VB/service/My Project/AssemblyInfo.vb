﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Security.Permissions

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("service")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("Copyright @ Microsoft 2004")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 
<Assembly: CLSCompliant(True)> 
<Assembly: SecurityPermissionAttribute(SecurityAction.RequestMinimum)> 
<Assembly: AssemblyConfiguration("")> 
<Assembly: AssemblyCulture("")> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("fb924f8a-31fa-4d8e-bc7c-045a47c0b71b")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
